package ec.ady.fontcontrol;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(10,12,16), PANEL=Color.rgb(24,28,36), ACCENT=Color.rgb(255,190,40);
    private TextView sizeValue, status, sample;
    private Button permissionButton, minusButton, plusButton;
    private LinearLayout fontControls;
    private GlyphTextView glyphPreview;
    private LinearLayout previewBox;
    private Spinner preset;
    private LinearLayout root;
    private float globalScale=1f, previewMultiplier=1f;
    private float lowerFailedAt=Float.NaN, upperFailedAt=Float.NaN;
    private final String[] glyphs="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,!?+-=:()".split("(?<=.)");
    private int glyphIndex=0;
    private final Map<String,ArrayList<ArrayList<float[]>>> drawn=new HashMap<>();
    private GlyphCanvas glyphCanvas;

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);globalScale=readScale();loadGlyphs();build();}
    private void build(){
        ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(20),dp(18),dp(30));root.setBackgroundColor(BG);sc.addView(root);setContentView(sc);
        TextView title=text("Tamaño y fuente",28,true);title.setTextColor(ACCENT);root.addView(title);
        TextView help=text("Ajusta el tamaño del sistema cuando Android lo permita. La vista previa y tu alfabeto dibujado se usan dentro de esta app.",16,false);help.setPadding(0,dp(8),0,dp(18));root.addView(help);
        TextView previewHead=text("VISTA PREVIA",14,true);previewHead.setTextColor(ACCENT);root.addView(previewHead);
        previewBox=new LinearLayout(this);previewBox.setOrientation(LinearLayout.VERTICAL);previewBox.setBackgroundColor(PANEL);previewBox.setPadding(dp(14),dp(14),dp(14),dp(14));sample=text("La lectura cómoda importa. Este párrafo largo sirve para observar cómo se ven las letras, las palabras y varias líneas cuando cambias el tamaño de fuente en tu teléfono.",20,false);sample.setTextColor(Color.WHITE);previewBox.addView(sample,match());glyphPreview=new GlyphTextView();previewBox.addView(glyphPreview,new LinearLayout.LayoutParams(-1,dp(150)));root.addView(previewBox,match());
        TextView current=text("Tamaño global actual",16,true);root.addView(current);
        permissionButton=button("Permitir modificar ajustes del sistema");permissionButton.setContentDescription("Permitir que la aplicación modifique el tamaño global de fuente");root.addView(permissionButton,match());permissionButton.setOnClickListener(v->{if(!Settings.System.canWrite(this)){try{startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception e){status.setText("No se pudieron abrir los ajustes de permiso.");}}else refreshPermissionControls();});
        fontControls=new LinearLayout(this);fontControls.setOrientation(LinearLayout.VERTICAL);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);minusButton=button("−");minusButton.setContentDescription("Reducir tamaño global de fuente");row.addView(minusButton,new LinearLayout.LayoutParams(0,dp(68),1));sizeValue=text("",26,true);sizeValue.setGravity(Gravity.CENTER);row.addView(sizeValue,new LinearLayout.LayoutParams(0,dp(68),2));plusButton=button("+");plusButton.setContentDescription("Aumentar tamaño global de fuente");row.addView(plusButton,new LinearLayout.LayoutParams(0,dp(68),1));fontControls.addView(row,match());TextView limitNote=text("Los botones se detienen cuando Android/XOS deja de aceptar más cambios.",14,false);limitNote.setTextColor(0xffffd27a);fontControls.addView(limitNote);root.addView(fontControls,match());minusButton.setOnClickListener(v->changeGlobal(-0.05f));plusButton.setOnClickListener(v->changeGlobal(0.05f));
        refreshPermissionControls();
        TextView fontTitle=text("Fuente de la vista previa",18,true);root.addView(fontTitle);preset=new Spinner(this);String[] options={"Sans serif del sistema","Serif","Monoespaciada","Mi fuente dibujada"};preset.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options));root.addView(preset,match());preset.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){updatePreview();}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        TextView local=text("Tamaño en la muestra (solo esta app)",15,true);root.addView(local);LinearLayout pr=new LinearLayout(this);Button pminus=button("−");pr.addView(pminus,new LinearLayout.LayoutParams(0,dp(56),1));TextView pm=text("100%",18,true);pm.setGravity(Gravity.CENTER);pr.addView(pm,new LinearLayout.LayoutParams(0,dp(56),2));Button pplus=button("+");pr.addView(pplus,new LinearLayout.LayoutParams(0,dp(56),1));root.addView(pr);pminus.setOnClickListener(v->{previewMultiplier=Math.max(.5f,previewMultiplier-.25f);pm.setText(Math.round(previewMultiplier*100)+"%");updatePreview();});pplus.setOnClickListener(v->{previewMultiplier=Math.min(8f,previewMultiplier+.25f);pm.setText(Math.round(previewMultiplier*100)+"%");updatePreview();});
        TextView drawTitle=text("Crear mi propia fuente",20,true);drawTitle.setTextColor(ACCENT);drawTitle.setPadding(0,dp(22),0,dp(4));root.addView(drawTitle);TextView drawHelp=text("Dibuja cada carácter en el recuadro negro. Los trazos se guardan en el teléfono y pueden verse en la muestra de esta app; no reemplazan la fuente de Android ni generan por sí solos un archivo TTF.",14,false);root.addView(drawHelp);
        TextView currentGlyph=text("",24,true);currentGlyph.setGravity(Gravity.CENTER);root.addView(currentGlyph);glyphCanvas=new GlyphCanvas();root.addView(glyphCanvas,new LinearLayout.LayoutParams(-1,dp(240)));
        Button clear=button("Borrar trazo del carácter");root.addView(clear,match());clear.setOnClickListener(v->{drawn.remove(glyphs[glyphIndex]);persistGlyphs();glyphCanvas.invalidate();if(glyphPreview!=null)glyphPreview.invalidate();});
        LinearLayout nav=new LinearLayout(this);Button prev=button("Anterior");Button next=button("Siguiente");nav.addView(prev,new LinearLayout.LayoutParams(0,dp(58),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(58),1));root.addView(nav);prev.setOnClickListener(v->{glyphIndex=(glyphIndex-1+glyphs.length)%glyphs.length;updateGlyph(currentGlyph);});next.setOnClickListener(v->{glyphIndex=(glyphIndex+1)%glyphs.length;updateGlyph(currentGlyph);});updateGlyph(currentGlyph);
        Button use=button("Usar mi fuente en la muestra");root.addView(use,match());use.setOnClickListener(v->{preset.setSelection(3);updatePreview();});
        status=text("Escala global: revisando permiso…",14,false);status.setPadding(0,dp(12),0,0);root.addView(status);updateScaleText();updatePreview();
    }
    private void changeGlobal(float d){
        if(!Settings.System.canWrite(this)){refreshPermissionControls();status.setText("Concede el permiso especial y vuelve a tocar el botón.");return;}
        float before=readScale(), target=before+d;
        if(!Float.isNaN(upperFailedAt)&&d>0&&Math.abs(before-upperFailedAt)<.001f){plusButton.setEnabled(false);return;}
        if(!Float.isNaN(lowerFailedAt)&&d<0&&Math.abs(before-lowerFailedAt)<.001f){minusButton.setEnabled(false);return;}
        if(minusButton!=null)minusButton.setEnabled(true);if(plusButton!=null)plusButton.setEnabled(true);
        try{
            boolean wrote=Settings.System.putFloat(getContentResolver(),Settings.System.FONT_SCALE,target);
            getWindow().getDecorView().postDelayed(()->{
                float after=readScale();globalScale=after;updateScaleText();
                boolean advanced=d>0?after>before+0.001f:after<before-0.001f;
                if(!advanced){if(d>0){upperFailedAt=before;plusButton.setEnabled(false);}else{lowerFailedAt=before;minusButton.setEnabled(false);}status.setText("Android/XOS no aceptó otro paso en ese sentido; desactivé ese botón.");}
                else{status.setText((wrote?"Tamaño aplicado: ":"El sistema ajustó el valor. Tamaño actual: ")+Math.round(after*100)+"%.");}
            },500);
        }catch(SecurityException e){refreshPermissionControls();status.setText("Android no concedió permiso para modificar los ajustes.");}
    }
    private void refreshPermissionControls(){
        boolean allowed=Settings.System.canWrite(this);
        if(permissionButton!=null){permissionButton.setText(allowed?"Permiso concedido ✓":"Permitir modificar ajustes del sistema");permissionButton.setEnabled(!allowed);permissionButton.setVisibility(allowed?View.GONE:View.VISIBLE);}
        if(fontControls!=null)fontControls.setVisibility(allowed?View.VISIBLE:View.GONE);
        if(allowed){globalScale=readScale();updateScaleText();if(minusButton!=null&&Math.abs(globalScale-lowerFailedAt)>.001f)minusButton.setEnabled(true);if(plusButton!=null&&Math.abs(globalScale-upperFailedAt)>.001f)plusButton.setEnabled(true);if(status!=null)status.setText("Escala actual. + y − se desactivan si el sistema rechaza más cambios.");}
    }
    @Override protected void onResume(){super.onResume();if(sizeValue!=null){globalScale=readScale();updateScaleText();refreshPermissionControls();}}
    private float readScale(){try{return Settings.System.getFloat(getContentResolver(),Settings.System.FONT_SCALE,1f);}catch(Exception e){return 1f;}}
    private void updateScaleText(){if(sizeValue!=null)sizeValue.setText(Math.round(globalScale*100)+"%");}
    private void updatePreview(){if(sample==null)return;int pos=preset==null?0:preset.getSelectedItemPosition();Typeface tf=pos==1?Typeface.SERIF:pos==2?Typeface.MONOSPACE:Typeface.DEFAULT;sample.setVisibility(pos==3?View.GONE:View.VISIBLE);glyphPreview.setVisibility(pos==3?View.VISIBLE:View.GONE);sample.setTypeface(tf);sample.setTextSize(20*previewMultiplier);glyphPreview.invalidate();}
    private void persistGlyphs(){try{JSONObject all=new JSONObject();for(Map.Entry<String,ArrayList<ArrayList<float[]>>> e:drawn.entrySet()){JSONArray lines=new JSONArray();for(ArrayList<float[]> line:e.getValue()){JSONArray pts=new JSONArray();for(float[] q:line){JSONArray xy=new JSONArray();xy.put(q[0]);xy.put(q[1]);pts.put(xy);}lines.put(pts);}all.put(e.getKey(),lines);}getSharedPreferences("glyphs",MODE_PRIVATE).edit().putString("strokes",all.toString()).apply();}catch(Exception ignored){}}
    private void loadGlyphs(){try{String raw=getSharedPreferences("glyphs",MODE_PRIVATE).getString("strokes","{}");JSONObject all=new JSONObject(raw);Iterator<String> keys=all.keys();while(keys.hasNext()){String key=keys.next();JSONArray lines=all.getJSONArray(key);ArrayList<ArrayList<float[]>> result=new ArrayList<>();for(int i=0;i<lines.length();i++){JSONArray pts=lines.getJSONArray(i);ArrayList<float[]> line=new ArrayList<>();for(int j=0;j<pts.length();j++){JSONArray xy=pts.getJSONArray(j);line.add(new float[]{(float)xy.getDouble(0),(float)xy.getDouble(1)});}result.add(line);}drawn.put(key,result);}}catch(Exception ignored){}}
    private void updateGlyph(TextView t){t.setText("Dibuja:  "+glyphs[glyphIndex]);glyphCanvas.invalidate();}
    private TextView text(String s,int size,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.WHITE);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(0,dp(5),0,dp(5));return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(18);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff49380f));return b;}
    private LinearLayout.LayoutParams match(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(8));return p;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private final class GlyphTextView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        GlyphTextView(){super(MainActivity.this);setBackgroundColor(PANEL);setContentDescription("Muestra el alfabeto dibujado por ti");}
        @Override protected void onDraw(Canvas c){super.onDraw(c);p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));c.drawRect(0,0,getWidth()-1,getHeight()-1,p);p.setStyle(Paint.Style.FILL);p.setTextSize(dp(15));p.setColor(ACCENT);c.drawText("Vista previa de los caracteres que dibujaste:",dp(6),dp(19),p);String sampleText="Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz 0123456789";float cellW=dp(18),cellH=dp(26),left=dp(7),top=dp(31);for(int i=0;i<sampleText.length();i++){char ch=sampleText.charAt(i);if(ch==' '){left+=cellW*.55f;continue;}if(left+cellW>getWidth()){left=dp(7);top+=cellH;if(top+cellH>getHeight())break;}ArrayList<ArrayList<float[]>> lines=drawn.get(String.valueOf(ch));if(lines==null||lines.isEmpty()){p.setColor(0xff888888);p.setTextSize(dp(17));c.drawText(String.valueOf(ch),left,top+dp(19),p);}else{p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.7f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);for(ArrayList<float[]> line:lines){if(line.size()<1)continue;Path path=new Path();path.moveTo(left+line.get(0)[0]*cellW,top+line.get(0)[1]*cellH);for(int j=1;j<line.size();j++)path.lineTo(left+line.get(j)[0]*cellW,top+line.get(j)[1]*cellH);c.drawPath(path,p);}p.setStyle(Paint.Style.FILL);}left+=cellW;}}
    }
    private final class GlyphCanvas extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private ArrayList<ArrayList<float[]>> strokes;
        GlyphCanvas(){super(MainActivity.this);setBackgroundColor(Color.BLACK);setContentDescription("Lienzo negro para dibujar el carácter actual con el dedo");}
        @Override protected void onDraw(Canvas c){super.onDraw(c);String g=glyphs[glyphIndex];strokes=drawn.computeIfAbsent(g,k->new ArrayList<>());paint.setColor(0xff555555);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));c.drawRect(1,1,getWidth()-1,getHeight()-1,paint);paint.setColor(0xff333333);c.drawLine(getWidth()*.12f,getHeight()*.78f,getWidth()*.88f,getHeight()*.78f,paint);paint.setColor(Color.WHITE);paint.setStrokeWidth(dp(4));paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);for(ArrayList<float[]> line:strokes){if(line.size()<1)continue;Path p=new Path();p.moveTo(line.get(0)[0]*getWidth(),line.get(0)[1]*getHeight());for(int i=1;i<line.size();i++)p.lineTo(line.get(i)[0]*getWidth(),line.get(i)[1]*getHeight());c.drawPath(p,paint);}}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=Math.max(0,Math.min(1,e.getX()/Math.max(1,getWidth()))),y=Math.max(0,Math.min(1,e.getY()/Math.max(1,getHeight())));String g=glyphs[glyphIndex];ArrayList<ArrayList<float[]>> lines=drawn.computeIfAbsent(g,k->new ArrayList<>());if(e.getAction()==android.view.MotionEvent.ACTION_DOWN){ArrayList<float[]> line=new ArrayList<>();line.add(new float[]{x,y});lines.add(line);invalidate();return true;}if(e.getAction()==android.view.MotionEvent.ACTION_MOVE){if(!lines.isEmpty())lines.get(lines.size()-1).add(new float[]{x,y});invalidate();return true;}return e.getAction()==android.view.MotionEvent.ACTION_UP;}
    }
}
